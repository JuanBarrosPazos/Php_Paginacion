<html>
<body>
<?php

require 'config.php';



/******************************************************/
/******************************************************/
/* Funcion paginar
* actual: Pagina actual
* total: Total de registros
* por_pagina: Registros por pagina
* enlace: Texto del enlace
* maxpags: El máximo de páginas a presentar simultáneamente (opcional)
* Devuelve un texto que representa la paginacion
*/
function paginar($actual, $total, $por_pagina, $enlace, $maxpags=0) {
    $total_paginas = ceil($total/$por_pagina);
    $anterior = $actual - 1;
    $posterior = $actual + 1;
    $minimo = $maxpags ? max(1, $actual-ceil($maxpags/2)): 1;
    $maximo = $maxpags ? min($total_paginas, $actual+floor($maxpags/2)): $total_paginas;
    if ($actual>1)
    $texto = "<a href=".$enlace.$anterior.">&laquo;</a> ";
    else
    $texto = "<b>&laquo;</b> ";
    if ($minimo!=1) $texto.= "... ";
    for ($i=$minimo; $i<$actual; $i++)
    $texto .= "<a href=".$enlace.$i.">$i</a> ";
    $texto .= "<b>$actual</b> ";
    for ($i=$actual+1; $i<=$maximo; $i++)
    $texto .= "<a href=".$enlace.$i.">$i</a> ";
    if ($maximo!=$total_paginas) $texto.= "... ";
    if ($actual<$total_paginas)
    $texto .= "<a href=".$enlace.$posterior.">&raquo;</a>";
    else
    $texto .= "<b>&raquo;</b>";
    return $texto;
    }
/******************************************************/

// Cuantos registros presentamos por pagina

if (!isset($pag)){

    if(isset($_GET['pag'])!=1){ global $pag;
                                $pag = 1;}
        else{ global $pag;
              $pag = $_GET['pag'];}

      //Por defecto, pagina 1

    $result = mysqli_query($link, "SELECT COUNT(*) FROM `country`");
    list($total) = mysqli_fetch_row($result);

    global $tampag;
    $tampag = 10;
    global $reg1;
    $reg1 = ($pag-1) * $tampag;
    global $result;
    $result = mysqli_query($link, "SELECT `Name`, `Continent` FROM `country`
    LIMIT $reg1, $tampag" );
    }
///////////////

if (mysqli_num_rows($result)){
echo "<table border = '1'>
";
echo "<tr><td>NOMBRE</td><td>CONTINENTE</td></tr>
";
while ($row = @mysqli_fetch_array($result)) {
echo "<tr><td>".$row["Name"].
"</td><td>".$row["Continent"]."</td></tr>
";
}
echo "</table>";
}
else
echo "¡ No se ha encontrado ningún registro !";

echo paginar($pag, $total, $tampag, "index1.php?pag=");

?>
</body>
</html>