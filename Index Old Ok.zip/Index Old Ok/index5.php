
<?php session_start(); ?>

<html>
    <body>

<?php

require 'config.php';

/* **************************************************** */

if (!isset($_GET['pag'])){  global $pag;
                            $pag = 1;
                            process();
                            }
                        else{ global $pag;
                              $pag = $_GET['pag'];
                              process();
                                }
    
/* **************************************************** */

function process(){

    global $link;
    global $pag;

    if(!isset($_SESSION['idioma'])){
        $_SESSION['idioma'] = "English";} 

    global $lg;
    $lg = "'".trim($_SESSION['idioma'])."'";
    
    $result = mysqli_query($link, "SELECT COUNT(*) FROM country INNER JOIN countrylanguage ON country.Code = countrylanguage.CountryCode WHERE countrylanguage.Language = $lg ");
    list($total) = mysqli_fetch_row($result);
   
    global $tampag;
    $tampag = 12;
    global $reg1;
    $reg1 = ($pag-1) * $tampag;
    global $result;

    global $lg2;
    $lg2 = "'".trim($_SESSION['idioma'])."'";
    $result = mysqli_query($link, "SELECT * FROM country INNER JOIN countrylanguage ON country.Code = countrylanguage.CountryCode WHERE countrylanguage.Language = $lg2 ORDER BY country.Code ASC LIMIT $reg1, $tampag");

echo $_SESSION['idioma'];

    if (mysqli_num_rows($result)){
        echo "<table border = '1'>
        ";
        echo "<tr><td> C. CODE </td><td> LANGUAGE </td><td> CODE </td><td> NOMBRE </td><td> CONTINENTE </td><td>REGION</td></tr>
        ";
        while ($row = @mysqli_fetch_array($result)) {
                echo "<tr>
                <td> ".$row['CountryCode']." </td>
                <td> ".$row['Language']." </td>
                <td> ".$row['Code']." </td>
                <td> ".$row['Name']." </td>
                <td> ".$row['Region']." </td>
                <td> ".$row['Continent']." </td>
                </tr>";
                }
        echo "</table>";
        }
        else
        echo "¡ No se ha encontrado ningún registro !";

        echo paginar($pag, $total, $tampag, "index.php?pag=");
    }

/* **************************************************** */

/* Funcion paginar
* actual: Pagina actual
* total: Total de registros
* por_pagina: Registros por pagina
* enlace: Texto del enlace
* maxpags: El máximo de páginas a presentar simultáneamente (opcional)
* Devuelve un texto que representa la paginacion
*/
function paginar($actual, $total, $por_pagina, $enlace, $maxpags=0) {
    $total_paginas = ceil($total/$por_pagina);
    $anterior = $actual - 1;
    $posterior = $actual + 1;
    $minimo = $maxpags ? max(1, $actual-ceil($maxpags/2)): 1;
    $maximo = $maxpags ? min($total_paginas, $actual+floor($maxpags/2)): $total_paginas;
    if ($actual>1)
    $texto = "<a href=".$enlace.$anterior.">&laquo;</a> ";
    else
    $texto = "<b>&laquo;</b> ";
    if ($minimo!=1) $texto.= "... ";
    for ($i=$minimo; $i<$actual; $i++)
    $texto .= "<a href=".$enlace.$i.">$i</a> ";
    $texto .= "<b>$actual</b> ";
    for ($i=$actual+1; $i<=$maximo; $i++)
    $texto .= "<a href=".$enlace.$i.">$i</a> ";
    if ($maximo!=$total_paginas) $texto.= "... ";
    if ($actual<$total_paginas)
    $texto .= "<a href=".$enlace.$posterior.">&raquo;</a>";
    else
    $texto .= "<b>&raquo;</b>";
    return $texto;
    }

    /* **************************************************** */

?>

    </body>
</html>