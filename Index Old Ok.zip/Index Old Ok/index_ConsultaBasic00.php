
<body>

<html>
<body>
<?php
//Conectamos a la base de datos
require 'config.php';

//Realiza la consulta en el orden de ID ascendente (cambiar "id" por, por ejemplo, "nombre" //Limitada por la cantidad de cantidad por página
$result = "SELECT * FROM `country` ORDER BY `Name` ASC LIMIT 8";
$qb = mysqli_query($conexion, $result);
$numrows = mysqli_num_rows($qb);
echo $numrows;
//$datos = mysqli_fetch_assoc($qb);

if ($numrows > 0){
echo "<table border = '1'>
";
echo "<tr><td>Nombre</td><td>Continente</td></tr>
";
while ($row = mysqli_fetch_assoc($qb)) {
echo "<tr><td>".$row["Name"].
"</td><td>".$row["Continent"]."</td></tr>
";
}
echo "</table>
";
}
else
echo "¡ No se ha encontrado ningún registro !";
?>
</body>