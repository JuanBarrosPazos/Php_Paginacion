<html>
<body>
<?php

require 'config.php';

$result = mysqli_query($link, "SELECT `Name`, `Continent` FROM `country`" );
if (mysqli_num_rows($result)){
echo "<table border = '1'>
";
echo "<tr><td>NOMBRE</td><td>CONTINENTE</td></tr>
";
while ($row = @mysqli_fetch_array($result)) {
echo "<tr><td>".$row["Name"].
"</td><td>".$row["Continent"]."</td></tr>
";
}
echo "</table>
";
}
else
echo "¡ No se ha encontrado ningún registro !";
?>
</body>
</html>