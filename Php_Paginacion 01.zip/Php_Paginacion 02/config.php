<?php
/*
define('DB_SERVER', '127.0.0.1');
define('DB_SERVER_USERNAME', 'JuanBarros');
define('DB_SERVER_PASSWORD', 'MariaPazos');
define('DB_DATABASE', 'world');
define('NUM_ITEMS_BY_PAGE', 6);

global $connexion;
$connexion = new mysqli(DB_SERVER, DB_SERVER_USERNAME, DB_SERVER_PASSWORD, DB_DATABASE);
*/

global $connexion;
global $db_name;

$db_host = '127.0.0.1'; 
$db_user = 'JuanBarros'; 
$db_pass = 'MariaPazos'; 
$db_name = 'world'; 

$connexion = mysqli_connect($db_host,$db_user,$db_pass,$db_name);
if (!$connexion){ die ("Es imposible conectar con la bbdd ".$db_name."</br>".mysqli_connect_error());
        }

?>