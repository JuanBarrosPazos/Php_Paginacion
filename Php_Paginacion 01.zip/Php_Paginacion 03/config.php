<?php

global $conexion;
global $db_name;

$db_host = '127.0.0.1'; 
$db_user = 'JuanBarros'; 
$db_pass = 'MariaPazos'; 
$db_name = 'world'; 

$conexion = mysqli_connect($db_host,$db_user,$db_pass,$db_name);
if (!$conexion){ die ("Es imposible conectar con la bbdd ".$db_name."</br>".mysqli_connect_error());
        }

?>