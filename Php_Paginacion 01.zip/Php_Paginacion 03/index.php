<body>

<?php

//Conectamos a la base de datos
require('config.php');

//Evitamos que salgan errores por variables vacías
//error_reporting(E_ALL ^ E_NOTICE);

//Cantidad de resultados por página (debe ser INT, no string/varchar)
$cantidad_resultados_por_pagina = 10;

// 1. Comprueba si está seteado el GET de HTTP
if (isset($_GET["pagina"])) {

    // 2. Si el GET de HTTP SÍ es una string / cadena
    if (is_string($_GET["pagina"])) {

        // 3. Si la string es numérica, define la variable 'pagina'
        if (is_numeric($_GET["pagina"])) {

            // 4. Si la petición desde la paginación es la página uno
            //en lugar de ir a 'index.php?pagina=1' se iría directamente 
                if ($_GET["pagina"] == 1) { header("Location: index.php");
                                            die();
                    } else { //Si la petición desde la paginación no es para ir 
                        $pagina = $_GET["pagina"];
                } // FIN 4. IF Y ELSE

        } // FIN 3.
            else { //Si la string no es numérica, redirige al index (por ejemplo: 
                        header("Location: index.php");
                        die();
                    }
    } // FIN 2.

} // FIN 1.
 else { //Si el GET de HTTP no está seteado, lleva a la primera página (puede ser cambiado 
            $pagina = 1;
        }
    
//Define el número 0 para empezar a paginar multiplicado por la cantidad de resultados 
    global $empezar_desde;
    $empezar_desde = ($pagina-1) * $cantidad_resultados_por_pagina;


    //Obtiene TODO de la tabla
        $obtener_todo_BD = "SELECT * FROM country";

    //Realiza la consulta
        $consulta_todo = mysqli_query($conexion, $obtener_todo_BD);

    //Cuenta el número total de registros
        $total_registros = mysqli_num_rows($consulta_todo);

    //Obtiene el total de páginas existentes
        $total_paginas = ceil($total_registros / $cantidad_resultados_por_pagina);

    //Realiza la consulta en el orden de ID ascendente (cambiar "id" por, por ejemplo, "nombre" //Limitada por la cantidad de cantidad por página
        $consulta_resultados = mysqli_query($conexion, "SELECT * FROM `country` ORDER BY `country`.`Name` ASC LIMIT $empezar_desde, $cantidad_resultados_por_pagina");

    //Crea un bluce 'while' y define a la variable 'datos' ($datos) como clave del array
    //que mostrará los resultados por nombre

    while($datos = mysqli_fetch_array($consulta_resultados)) {
    ?>
        <p><strong><?php echo $datos['Name']; ?></strong> <br>
        <?php echo $datos['Code']; ?></p>
    <?php
        }
    ?>

    <hr><!----------------------------------------------->

    | <?php

    //Crea un bucle donde $i es igual 1, y hasta que $i sea menor o igual a X, a sumar (1, //Nota: X = $total_paginas
    for ($i=1; $i<=$total_paginas; $i++) {
    //En el bucle, muestra la paginación
    echo "<a href='?pagina=".$i."'>".$i."</a> | ";
    } 

?>

</body>
