<?php 

require('config.php');

$result =  "SELECT * FROM country ";
$q = mysqli_query($connexion, $result);
$row = mysqli_fetch_assoc($q);
$num_total_rows = mysqli_num_rows($q);;

global $nitem;
$nitem = 18;
?>

<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Paginación de resultados con PHP Demo</title>
<meta name="description" content="Paginación de resultados con PHP."/>
<link rel="stylesheet" href="css/font-awesome.min.css">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/styles.css">
<script src="js/jquery-3.2.1.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</head>

<body>
<div class="container">
    <h2 class="lead"><?php echo $num_total_rows." elementos listados de ".$nitem." en ".$nitem.".</h2>";?>
    
    <div class="row">
        <div id="content" class="col-lg-12">
<?php
if ($num_total_rows > 0) {
    $page = false;

    //examino la pagina a mostrar y el inicio del registro a mostrar
    if (isset($_GET["page"])) {
        $page = $_GET["page"];
    }

    if (!$page) {
        $start = 0;
        $page = 1;
    } else {
        $start = ($page - 1) * $nitem;
    }
    //calculo el total de paginas
    $total_pages = ceil($num_total_rows / $nitem);

    //pongo el n�mero de registros total, el tama�o de p�gina y la p�gina que se muestra
    echo '<h3>N&uacute;mero de resultados: '.$num_total_rows.'</h3>';
    echo '<h3>P&aacute;gina '.$page.' de ' .$total_pages.' p&aacute;ginas.</h3>';

    $result = mysqli_query($connexion, "SELECT * FROM country WHERE Code != 1 ORDER BY Name ASC LIMIT ".$start.", ".$nitem );

    if (mysqli_num_rows($result) > 0) {
        echo '<ul class="row items">';
        while ($row = $result->fetch_assoc()) {
            echo '<div class="item">';
            echo '<h3>'.$row['Name'].'</h3>';
            echo '</div>';
        }
        echo '</ul>';
    }

    echo '<nav>';
    echo '<ul class="pagination">';

    if ($total_pages > 1) {
        if ($page != 1) {
            echo '<li class="page-item"><a class="page-link" href="index.php?page='.($page-1).'"><span aria-hidden="true">&laquo;</span></a></li>';
        }

        for ($i=1;$i<=$total_pages;$i++) {
            if ($page == $i) {
                echo '<li class="page-item active"><a class="page-link" href="#">'.$page.'</a></li>';
            } else {
                echo '<li class="page-item"><a class="page-link" href="index.php?page='.$i.'">'.$i.'</a></li>';
            }
        }

        if ($page != $total_pages) {
            echo '<li class="page-item"><a class="page-link" href="index.php?page='.($page+1).'"><span aria-hidden="true">&raquo;</span></a></li>';
        }
    }
    echo '</ul>';
    echo '</nav>';
}
?>
        </div>
    </div>
    
    
</div>

    </body>
</html>
